EPM (Enterprise Password Manager)
==================================

This software is provided as is and is free for everyone.
This software is distributed under GNU GPL. Please read the
license.txt file for details.

Owner/developer has full rights over the content and it modifications.
Any change and modification done to the software and distributed there on
would violate GNU GPL.

Enjoy the software and express your views in 
Facebook(https://www.facebook.com/pages/Free-Enterprise-Password-Manager/599708640053055)
 / Wordpress blog site (krishg73.wordpress.com)
